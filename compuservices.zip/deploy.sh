# Run Database Migrations
php artisan migrate:fresh

# Run seeds
php artisan db:seed