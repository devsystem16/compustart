<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class Status extends Model
{
    protected $table = 'status';
    // protected $primaryKey = 'IDStatus';
}
