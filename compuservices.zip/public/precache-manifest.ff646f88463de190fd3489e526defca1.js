self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1a1b111e7c2880fde404a9c67dbbeb48",
    "url": "/index.html"
  },
  {
    "revision": "0547ce1d6363bc7056e3",
    "url": "/static/css/2.2b64612d.chunk.css"
  },
  {
    "revision": "e972434a3a6beb12b77b",
    "url": "/static/css/main.bc0fe56a.chunk.css"
  },
  {
    "revision": "0547ce1d6363bc7056e3",
    "url": "/static/js/2.4508db18.chunk.js"
  },
  {
    "revision": "e972434a3a6beb12b77b",
    "url": "/static/js/main.cd6309e2.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "9e6cd5bd86cedcb6f3ae2cae59b466b8",
    "url": "/static/media/logoCompuservices.9e6cd5bd.PNG"
  }
]);