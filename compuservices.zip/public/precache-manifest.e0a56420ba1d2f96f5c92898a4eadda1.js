self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5cc598abf840d87be1eae08a82e479af",
    "url": "/index.html"
  },
  {
    "revision": "98bbc237dc2275b0b0a4",
    "url": "/static/css/2.7a852dec.chunk.css"
  },
  {
    "revision": "ebca2b6399d7f8cbdbf0",
    "url": "/static/css/main.e7f395a8.chunk.css"
  },
  {
    "revision": "98bbc237dc2275b0b0a4",
    "url": "/static/js/2.7115313c.chunk.js"
  },
  {
    "revision": "ebca2b6399d7f8cbdbf0",
    "url": "/static/js/main.3456376f.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "611cb07c55179da12df3e6566aa09339",
    "url": "/static/media/logoCompuservices.611cb07c.PNG"
  }
]);